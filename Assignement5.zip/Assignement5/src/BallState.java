public interface BallState {
    public void setSpeed(int speed);

	public void setSize(int size);
	public void setType(String Types);
}