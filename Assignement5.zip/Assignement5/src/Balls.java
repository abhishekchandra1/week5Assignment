public class Balls
{
    BallState ball = null;
    String balltype;

    Balls(){
        this.ball = new MediumBall();
        this.balltype=balltype;
    }

    public void start(BallState gs){
        this.ball = gs;
    }

    public void changeSize(BallState gs){
        this.ball = gs;
    }
    public void ballType(String balltype) {
    	this.ball.setType(balltype);
    }

    public void speed(int speed){
        this.ball.setSpeed(speed);
    }
}