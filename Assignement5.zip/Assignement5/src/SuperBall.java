public class SuperBall implements BallState
{
    public void setSpeed(int speed) {
		setSize(speed);
	}

	public void setSize(int size) {
        if(size>500){
            System.out.println("Balls not go above 300km/h ; This is not artificial Ball man!!");
        }else{
            System.out.println("Ball will go at Speed :" + size);
        }
    }

	@Override
	public void setType(String Types) {
		if (Types == "Cricket") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="HockeyBall") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Basketball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Tanis") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Football") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="bollyball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else {
			System.out.print("Ball is a Not a Ball");
		}
	}


}