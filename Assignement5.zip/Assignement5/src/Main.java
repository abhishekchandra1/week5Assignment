class Main
{
    public static void main(String args[])
    {
        BallState g0 = new MediumBall();
        BallState g1 = new FirstType();
        BallState g2 = new SecondType();
        BallState g3 = new SuperBall();

        Balls c = new Balls();
        c.start(g0);
        c.speed(20);
        c.changeSize(g2);
        c.ballType("Football");
        c.speed(30);
        c.changeSize(g1);
        c.ballType("WollyBall");
        c.speed(40);
        c.changeSize(g3);
        c.ballType("bollball");
        c.speed(50);
        c.changeSize(g3);
        c.ballType("Cricket");

    }
}
