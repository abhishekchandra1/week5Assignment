public class FirstType implements BallState
{
    public void setSpeed(int size) {
		setSize(size);
	}

	public void setSize(int size) {
        if(size>50){
            System.out.println("This Ball Is Too Big ; Change ball");
        }else{
            System.out.println("Ball will go at Speed :" + size+"cm");
        }
    }

	@Override
	public void setType(String Types) {
		if (Types == "Cricket") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="HockeyBall") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Basketball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Tanis") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Football") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="bollyball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else {
			System.out.print("Ball is a Not a Ball");
		}
	}
}