public class MediumBall implements BallState
{
    public void setSpeed(int speed) {
		setSize(speed);
	}

	public void setSize(int speed) {
        if(speed>0){
            System.out.println("The Balls is in neutral state; Try changing ball");
        }
    }

	@Override
	public void setType(String Types) {
		if (Types == "Cricket") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="HockeyBall") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Basketball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Tanis") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Football") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="bollyball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else {
			System.out.print("Ball is a Not a Ball");
		}
	}
}