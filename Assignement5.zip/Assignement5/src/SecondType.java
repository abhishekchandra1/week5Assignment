public class SecondType implements BallState
{
    public void setSpeed(int speed) {
		setSize(speed);
	}

	public void setSize(int speed) {
        if(speed>200){
            System.out.println("Balls not go Beyond 200Km/h; Try  to throgh superfast");
        }else{
            System.out.println("Ball is at Speed :" + speed);
        }
	}

	@Override

	public void setType(String Types) {
		if (Types == "Cricket") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="HockeyBall") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Basketball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Tanis") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="Football") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else if(Types=="bollyball") {
			System.out.print("Ball is a "+Types+"Ball");
		}
		else {
			System.out.print("Ball is a Not a Ball");
		}
	}
}

